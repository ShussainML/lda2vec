lda2vec.lda2vec module
----------------------

.. automodule:: lda2vec.lda2vec
    :members:
    :undoc-members:
    :show-inheritance:
